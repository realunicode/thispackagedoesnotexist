import socket
import struct
import logging
import asyncio
import uuid
from typing import Dict, Set, Optional
import platform

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ReverseSocksProxy:
    SOCKS_VERSION = 5
    CMD_REGISTER = 0x01
    CMD_CONNECT = 0x02
    CMD_DATA = 0x03
    CMD_CLOSE = 0x04
    CMD_PING = 0x05
    BUFFER_SIZE = 32768

    def __init__(self, listen_host: str, listen_port: int, server_host: str, server_port: int, socks_port: Optional[int] = None):
        self.listen_host = listen_host
        self.listen_port = listen_port
        self.server_host = server_host
        self.server_port = server_port
        self.socks_port = socks_port or 1080
        self.running = False
        self.reverse_clients = []
        self.tunnels: Dict[str, dict] = {}
        self.active_tunnels: Set[str] = set()
        
    async def safe_close_writer(self, writer):
        """Safely close a writer with proper error handling"""
        try:
            if not writer.is_closing():
                if platform.system() == 'Windows':
                    try:
                        if hasattr(writer, '_sock'):
                            try:
                                writer._sock.shutdown(socket.SHUT_WR)
                            except (OSError, AttributeError) as e:
                                if not isinstance(e, OSError) or e.winerror != 10038:
                                    logger.debug(f"Socket shutdown error: {e}")
                    except Exception as e:
                        logger.debug(f"Error checking writer state: {e}")
                else:
                    writer.close()
                    await writer.wait_closed()
        except Exception as e:
            logger.debug(f"Error during writer cleanup: {e}")

    async def safe_close_reader(self, reader):
        """Safely close a reader with proper error handling"""
        try:
            if not reader.is_closing():
                if platform.system() == 'Windows':
                    try:
                        if hasattr(reader, '_sock'):
                            try:
                                reader._sock.shutdown(socket.SHUT_RD)
                            except (OSError, AttributeError) as e:
                                if not isinstance(e, OSError) or e.winerror != 10038: 
                                    logger.debug(f"Socket shutdown error: {e}")
                    except Exception as e:
                        logger.debug(f"Error checking reader state: {e}")
                else:
                    reader.close()
                    await reader.wait_closed()
        except Exception as e:
            logger.debug(f"Error during reader cleanup: {e}")

    async def safe_close_connection(self, reader, writer):
        """Safely close both reader and writer with proper error handling"""
        try:
            await self.safe_close_writer(writer)
            await self.safe_close_reader(reader)
        except Exception as e:
            logger.debug(f"Error during connection cleanup: {e}")

    async def start_client(self):
        logger.info(f"Starting reverse SOCKS client, connecting to {self.server_host}:{self.server_port}")
        self.client_id = str(uuid.uuid4()).encode()
        
        while self.running:
            try:
                reader, writer = await asyncio.open_connection(
                    self.server_host, 
                    self.server_port
                )
                logger.info(f"Connected to server at {self.server_host}:{self.server_port}")
                try:
                    await self.send_packet(writer, self.CMD_REGISTER, self.client_id)
                except Exception as e:
                    logger.error(f"Failed to send registration packet: {e}")
                    await self.safe_close_connection(reader, writer)
                    continue
                
                asyncio.create_task(self.client_heartbeat(writer))
                await self.handle_client_connection(reader, writer)
            except Exception as e:
                logger.error(f"Error in client: {e}")
                if self.running:
                    await asyncio.sleep(1)

    async def client_heartbeat(self, writer):
        while self.running:
            try:
                await self.send_packet(writer, self.CMD_PING, b'')
                await asyncio.sleep(30)
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")
                break

    async def handle_client_connection(self, reader, writer):
        while self.running:
            try:
                header = await reader.readexactly(5)
                cmd, size = header[0], struct.unpack('!I', header[1:5])[0]
                data = await reader.readexactly(size) if size > 0 else b''
                
                if cmd == self.CMD_CONNECT:
                    asyncio.create_task(self.handle_client_connect_request(writer, data))
                elif cmd == self.CMD_DATA:
                    tunnel_id = data[:36].decode()
                    if tunnel_id in self.active_tunnels:
                        await self.handle_client_data(tunnel_id, data[36:])
                elif cmd == self.CMD_CLOSE:
                    self.handle_client_tunnel_close(data[:36].decode())
            except asyncio.IncompleteReadError:
                break
            except Exception as e:
                logger.error(f"Error processing command: {e}")
                break
            
            await self.safe_close_connection(reader, writer)

    async def handle_client_connect_request(self, writer, data):
        tunnel_id = data[:36].decode()
        address_type = data[36]
        offset = 37

        try:
            if address_type == 1:
                target_addr = socket.inet_ntoa(data[offset:offset + 4])
                offset += 4
            elif address_type == 3:
                domain_length = data[offset]
                offset += 1
                target_addr = data[offset:offset + domain_length].decode('utf-8')
                offset += domain_length
            else:
                await self.send_connect_response(writer, tunnel_id, False)
                return

            target_port = struct.unpack('!H', data[offset:offset + 2])[0]
            
            try:
                target_reader, target_writer = await asyncio.open_connection(
                    target_addr, 
                    target_port
                )
                self.tunnels[tunnel_id] = {'reader': target_reader, 'writer': target_writer}
                self.active_tunnels.add(tunnel_id)
                await self.send_connect_response(writer, tunnel_id, True)
                asyncio.create_task(self.forward_target_to_server(writer, tunnel_id))
            except Exception as e:
                logger.error(f"Failed to connect to {target_addr}:{target_port}: {e}")
                await self.send_connect_response(writer, tunnel_id, False)
        except Exception as e:
            logger.error(f"Error in connect request: {e}")
            await self.send_connect_response(writer, tunnel_id, False)

    async def send_connect_response(self, writer, tunnel_id, success):
        try:
            response = tunnel_id.encode() + struct.pack('!B', 1 if success else 0)
            await self.send_packet(writer, self.CMD_CONNECT, response)
        except Exception as e:
            logger.error(f"Error sending connect response: {e}")

    async def handle_client_data(self, tunnel_id, data):
        if tunnel_id in self.tunnels:
            try:
                writer = self.tunnels[tunnel_id]['writer']
                writer.write(data)
                await writer.drain()
            except Exception as e:
                logger.error(f"Error handling client data: {e}")
                self.handle_client_tunnel_close(tunnel_id)

    async def handle_client_tunnel_close(self, tunnel_id):
        if tunnel_id in self.tunnels:
            try:
                reader = self.tunnels[tunnel_id]['reader']
                writer = self.tunnels[tunnel_id]['writer']
                await self.safe_close_connection(reader, writer)
            except Exception as e:
                logger.error(f"Error closing client tunnel: {e}")
            finally:
                self.active_tunnels.discard(tunnel_id)
                del self.tunnels[tunnel_id]

    async def forward_target_to_server(self, writer, tunnel_id):
        try:
            reader = self.tunnels[tunnel_id]['reader']
            while self.running and tunnel_id in self.active_tunnels:
                data = await reader.read(8192)
                if not data:
                    break
                payload = tunnel_id.encode() + data
                await self.send_packet(writer, self.CMD_DATA, payload)
        except Exception as e:
            logger.error(f"Error forwarding to server: {e}")
        finally:
            if tunnel_id in self.tunnels:
                try:
                    await self.send_packet(writer, self.CMD_CLOSE, tunnel_id.encode())
                except Exception as e:
                    logger.error(f"Error sending close packet: {e}")
                await self.handle_client_tunnel_close(tunnel_id)

    async def start_server(self):
        logger.info(f"Starting reverse SOCKS server on {self.listen_host}:{self.listen_port}")
        try:
            reverse_server = await asyncio.start_server(
                self.handle_reverse_client, 
                self.listen_host, 
                self.listen_port,
                reuse_address=True
            )
            socks_server = await asyncio.start_server(
                self.handle_socks_client, 
                self.listen_host, 
                self.socks_port,
                reuse_address=True
            )
            
            self.running = True
            async with reverse_server, socks_server:
                await asyncio.gather(
                    reverse_server.serve_forever(),
                    socks_server.serve_forever()
                )
        except Exception as e:
            logger.error(f"Server startup error: {e}")

    async def handle_reverse_client(self, reader, writer):
        try:
            header = await reader.readexactly(5)
            cmd, size = header[0], struct.unpack('!I', header[1:5])[0]
            data = await reader.readexactly(size) if size > 0 else b''
            
            if cmd == self.CMD_REGISTER:
                client_info = {
                    'reader': reader, 
                    'writer': writer, 
                    'id': data.decode(), 
                    'tunnels': {},
                    'active': True
                }
                self.reverse_clients.append(client_info)
                await self.handle_reverse_client_connection(client_info)
        except Exception as e:
            logger.error(f"Error in reverse client: {e}")
        finally:
            await self.safe_close_connection(reader, writer)

    async def handle_reverse_client_connection(self, client_info):
        reader = client_info['reader']
        try:
            while self.running and client_info['active']:
                header = await reader.readexactly(5)
                cmd, size = header[0], struct.unpack('!I', header[1:5])[0]
                data = await reader.readexactly(size) if size > 0 else b''
                
                if cmd == self.CMD_CONNECT:
                    tunnel_id, success = data[:36].decode(), data[36] == 1
                    self.handle_server_connect_response(client_info, tunnel_id, success)
                elif cmd == self.CMD_DATA:
                    tunnel_id = data[:36].decode()
                    if tunnel_id in client_info['tunnels']:
                        await self.handle_server_data(client_info, tunnel_id, data[36:])
                elif cmd == self.CMD_CLOSE:
                    self.handle_server_tunnel_close(client_info, data[:36].decode())
                elif cmd == self.CMD_PING:
                    continue
        except Exception as e:
            logger.error(f"Error in client connection: {e}")
        finally:
            client_info['active'] = False
            for tunnel_id in list(client_info['tunnels'].keys()):
                await self.handle_server_tunnel_close(client_info, tunnel_id)
            if client_info in self.reverse_clients:
                self.reverse_clients.remove(client_info)

    async def handle_socks_client(self, reader, writer):
        if not self.reverse_clients:
            try:
                await self.safe_close_writer(writer)
            except Exception as e:
                logger.error(f"Error closing empty client: {e}")
            return
        
        try:
            version, nmethods = struct.unpack('!BB', await reader.readexactly(2))
            if version != self.SOCKS_VERSION:
                await self.safe_close_writer(writer)
                return
            
            await reader.readexactly(nmethods)
            writer.write(struct.pack('!BB', self.SOCKS_VERSION, 0))
            await writer.drain()
            
            version, cmd, _, address_type = struct.unpack('!BBBB', await reader.readexactly(4))
            if cmd != 1:
                writer.write(struct.pack('!BBBB4sH', self.SOCKS_VERSION, 7, 0, 1, socket.inet_aton('0.0.0.0'), 0))
                await writer.drain()
                await self.safe_close_writer(writer)
                return
            
            if address_type == 1:
                addr_bytes = await reader.readexactly(4)
                target_addr = socket.inet_ntoa(addr_bytes)
            elif address_type == 3:
                domain_length = (await reader.readexactly(1))[0]
                target_addr = (await reader.readexactly(domain_length)).decode('utf-8')
                addr_bytes = struct.pack('!B', domain_length) + target_addr.encode('utf-8')
            else:
                writer.write(struct.pack('!BBBB4sH', self.SOCKS_VERSION, 8, 0, 1, socket.inet_aton('0.0.0.0'), 0))
                await writer.drain()
                await self.safe_close_writer(writer)
                return
            
            port_bytes = await reader.readexactly(2)
            target_port = struct.unpack('!H', port_bytes)[0]
            
            tunnel_id = str(uuid.uuid4())
            client_info = next((c for c in self.reverse_clients if c['active']), None)
            if not client_info:
                await self.safe_close_writer(writer)
                return
                
            tunnel_info = {'reader': reader, 'writer': writer, 'connecting': True}
            client_info['tunnels'][tunnel_id] = tunnel_info
            
            connect_data = tunnel_id.encode() + struct.pack('!B', address_type) + addr_bytes + port_bytes
            await self.send_packet(client_info['writer'], self.CMD_CONNECT, connect_data)
            asyncio.create_task(self.forward_socks_to_client(client_info, tunnel_id))
        except Exception as e:
            logger.error(f"Error in SOCKS client: {e}")
            try:
                await self.safe_close_writer(writer)
            except Exception as e:
                logger.error(f"Unexpected error closing SOCKS client: {e}")

    def handle_server_connect_response(self, client_info, tunnel_id, success):
        if tunnel_id in client_info['tunnels']:
            tunnel_info = client_info['tunnels'][tunnel_id]
            tunnel_info['connecting'] = False
            writer = tunnel_info['writer']
            resp = struct.pack('!BBBB4sH', self.SOCKS_VERSION, 0 if success else 5, 0, 1, socket.inet_aton('0.0.0.0'), 0)
            try:
                writer.write(resp)
                if not success:
                    asyncio.create_task(self.handle_server_tunnel_close(client_info, tunnel_id))
            except Exception as e:
                logger.error(f"Error sending connect response: {e}")
                asyncio.create_task(self.handle_server_tunnel_close(client_info, tunnel_id))

    async def handle_server_data(self, client_info, tunnel_id, data):
        if tunnel_id in client_info['tunnels']:
            writer = client_info['tunnels'][tunnel_id]['writer']
            try:
                writer.write(data)
                await writer.drain()
            except Exception as e:
                logger.error(f"Error handling server data: {e}")
                await self.handle_server_tunnel_close(client_info, tunnel_id)

    async def handle_server_tunnel_close(self, client_info, tunnel_id):
        if tunnel_id in client_info['tunnels']:
            try:
                reader = client_info['tunnels'][tunnel_id]['reader']
                writer = client_info['tunnels'][tunnel_id]['writer']
                await self.safe_close_connection(reader, writer)
            except Exception as e:
                logger.error(f"Error closing server tunnel: {e}")
            finally:
                del client_info['tunnels'][tunnel_id]

    async def forward_socks_to_client(self, client_info, tunnel_id):
        try:
            reader = client_info['tunnels'][tunnel_id]['reader']
            while client_info['active'] and tunnel_id in client_info['tunnels']:
                if client_info['tunnels'][tunnel_id]['connecting']:
                    await asyncio.sleep(0.1)
                    continue
                data = await reader.read(8192)
                if not data:
                    break
                payload = tunnel_id.encode() + data
                await self.send_packet(client_info['writer'], self.CMD_DATA, payload)
        except Exception as e:
            logger.error(f"Error in SOCKS forward: {e}")
        finally:
            if tunnel_id in client_info['tunnels']:
                await self.handle_server_tunnel_close(client_info, tunnel_id)

    async def send_packet(self, writer, cmd, data):
        try:
            header = struct.pack('!BI', cmd, len(data))
            writer.write(header + data)
            await writer.drain()
        except Exception as e:
            logger.error(f"Error sending packet: {e}")
            raise

    def start(self, mode):
        """Start the proxy in either client or server mode"""
        self.running = True
        if mode == 'client':
            asyncio.run(self.start_client())
        elif mode == 'server':
            asyncio.run(self.start_server())

    def stop(self):
        """Stop the proxy"""
        self.running = False